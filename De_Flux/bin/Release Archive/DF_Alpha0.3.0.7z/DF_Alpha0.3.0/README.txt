De_Flux Alpha0.3.0

-------------------------------------------------------------------------
instructions:
-------------------------------------------------------------------------

� play:

	� double click the "De_Flux.bat" file to open the game
	  alternatively, you can run the De_Flux.exe file inside of
	  the DF_Alpha0.3.0 folder

	� move around..........W A S D

	� quit to main menu....Esc


� map maker:

	� Place Tile...........left-click

	� Remove Tile..........right-click

	� adjust camera........W A S D

	� Tile Type............scroll wheel up & down

	� zoom in and out......Shift + scroll up & down (or the R and F keys)

	� Save Map.............Ctrl + S (saves map to   \maps\ folder)

	� Load Map.............Ctrl + L (loads map from \maps\ folder)

	� Pick tile............middle-click or Q

	� leave mapmake........Esc


-------------------------------------------------------------------------
Developer's note
-------------------------------------------------------------------------

	This game is in alpha. in fact, one could hardly call it a game at all.
	This is really barebones and the team is still working
	hard to get the game up-to-snuff.

	The mapmaker was a priority for me because I want to be able to make maps
	for the game quickly and easily. I will continue development of this
	feature as long as I'm not satisfied with it.


-------------------------------------------------------------------------
Website
-------------------------------------------------------------------------

	if you want to check out other games from team Dai-Dungeon
	check out my website at:
	mavdisk.mnsu.edu/jenser5/index.html


-------------------------------------------------------------------------
The Team
-------------------------------------------------------------------------

� Programmer:

	� Ryan Jensen 		(JensenR30)


� Artists:

	� Peter Jacobson	(Solzerid)

	� Josh Pohl		(JPisaBrony)

	� Ryan Jensen		(JensenR30)


� Planning To Join The Team:

	� Jackson B		(Patar474)
