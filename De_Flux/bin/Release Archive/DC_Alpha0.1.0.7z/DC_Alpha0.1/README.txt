	this game is in alpha. in fact, one could hardly call it a game at all.
	this is really barebones and I am still working hard at getting the game
	playable with all the features I hope it to have.

instructions:
	double click the "Dungeon Crawler.bat" file to open the "game"
	use WASD and your mouse.

-------------------------------------------------------------------------

	if you want to check out one of my more developed games,
	check out my website at:

	-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
	mavdisk.mnsu.edu/jenser5/index.html
	-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
	
	there are some games and some programs and some electrical engineering projects and such.
	enjoy!



-------------------------------------------------------------------------
Ryan Jensen
December 2012