ANYWHERE: press 'h' for help/instructions

=================================================================================================
map maker controls:
=================================================================================================

- left click to place tile

- right click to remove tile

- E opens your inventory

- WASD to pan the camera

- Ctrl + S to save your map. (saves to \maps\)

- Ctrl + L to load your map. (loads from \maps\)

- R & F to zoom in and out

- Q to pick a tile from the map

- Esc to return to the title_screen.


=================================================================================================
play controls:
=================================================================================================

- WASD to move

- Esc to return to the title screen

- r & f to zoom in and out (or use shift + scroll)
