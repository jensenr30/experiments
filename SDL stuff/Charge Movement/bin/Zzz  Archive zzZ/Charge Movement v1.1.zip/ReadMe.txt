
Charge Movement v1.1
Ryan Jensen
2013-12-19
License: CC-BY-NC-SA 3.0 US

-------------------------------------------------------------------------------------------
CONTROLS
-------------------------------------------------------------------------------------------
Ctrl + Left Click
			place a charge

Ctrl + Right Click
			delete a charge

scroll up/down
			change charge value

Shift + scroll up/down
			change charge value a lot

middle click
			toggle charge polarity

Click and hold
			drag and drop charges to different locations
	
L
			toggle displaying lines
	
Space
			start/pause simulation

Tab
			move simulation forward a little bit then pause

Esc
			Reset all charges

-------------------------------------------------------------------------------------------
NOTES ABOUT THE GAME
-------------------------------------------------------------------------------------------
This Charge Simulator isn't perfect.
But the logic, math, and physics are all there.

This simulator will only run on Windows as far as I know.

-------------------------------------------------------------------------------------------
CONTACT
-------------------------------------------------------------------------------------------

Tell me if you have any concerns, or want to chat about the project
	name	Ryan Jensen
	email	JensenR30@GMail.com
	skype	Ryan.Jensen21
	
-------------------------------------------------------------------------------------------
DOGECOINS
-------------------------------------------------------------------------------------------
	
If you liked the simulator and would like to toss a few dogecoins my way, it would be much obliged. 
my wallet address is:

	D6smYpZB1SVJkZsxsPvM5dsKaWBsMkStB2


	
