

short int key_a_pressed = 0;
short int key_b_pressed = 0;
short int key_c_pressed = 0;
short int key_d_pressed = 0;
short int key_e_pressed = 0;
short int key_f_pressed = 0;
short int key_g_pressed = 0;
short int key_h_pressed = 0;
short int key_i_pressed = 0;
short int key_j_pressed = 0;
short int key_k_pressed = 0;
short int key_l_pressed = 0;
short int key_m_pressed = 0;
short int key_n_pressed = 0;
short int key_o_pressed = 0;
short int key_p_pressed = 0;
short int key_q_pressed = 0;
short int key_r_pressed = 0;
short int key_s_pressed = 0;
short int key_t_pressed = 0;
short int key_u_pressed = 0;
short int key_v_pressed = 0;
short int key_w_pressed = 0;
short int key_x_pressed = 0;
short int key_y_pressed = 0;
short int key_z_pressed = 0;
short int key_shift_pressed = 0;
short int key_control_pressed = 0;

short int mouse_button_1 = 0;
short int mouse_button_2 = 0;
short int mouse_button_3 = 0;
short int mouse_button_4 = 0;
short int mouse_button_5 = 0;
