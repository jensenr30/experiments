

void die()
{
	c();
	printf("\n\n\n\n\n          You Ran the \"die\"command!");
	p();
}

void suck()
{
	c();
	printf("\n\n\n\n\n          SUCK IT, BEE-YITCH! YOU RAN THE \"suck\" command!\n");
	p();
}

void hello(){c(); printf("You ran the hello command!\n"); p();}
void moo(){c(); printf("You ran the moo command!\n"); p();}
void copypasta(){c(); printf("You ran the copypasta command!\n"); p();}
void deathnote(){c(); printf("You ran the deathnote command!\n"); p();}
void spoonbash(){c(); printf("You ran the spoonbash command!\n"); p();}
void beep(){c(); printf("You ran the beep command!\a\n"); p();}
void minecraft(){c(); printf("You ran the minecraft command!\n"); p();}
void portal(){c(); printf("You ran the portal command!\n"); p();}
